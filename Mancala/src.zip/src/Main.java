
public class Main {
	
	public static GameWindow window;
	
	public static void main(String[] args) {
		window = new GameWindow();
	}

}
